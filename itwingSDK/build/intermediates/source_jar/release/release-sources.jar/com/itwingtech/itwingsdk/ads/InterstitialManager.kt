package com.itwingtech.itwingsdk.ads

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest
import com.google.android.libraries.ads.mobile.sdk.common.AdValue
import com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError
import com.google.android.libraries.ads.mobile.sdk.common.PreloadConfiguration
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAd
import com.itwingtech.itwingsdk.core.ITWingConfig
import java.util.concurrent.ConcurrentHashMap
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdEventCallback
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdPreloader
import com.itwingtech.itwingsdk.utils.NetworkState
import com.itwingtech.itwingsdk.utils.runOnMain
import com.itwingtech.itwingsdk.utils.safeCallback

class InterstitialManager(private val configProvider: () -> ITWingConfig, private val frequency: FrequencyController) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val loadedAds = ConcurrentHashMap<String, InterstitialAd>()
    private val preloaderKeys = ConcurrentHashMap<String, String>()
    private val lastLoadAttemptAt = ConcurrentHashMap<String, Long>()
    private val customRenderer = CustomFullscreenAdRenderer()
    private val minLoadIntervalMs = 20_000L

    fun preloadAll(activity: Activity) {
        val config = configProvider()
        config.ads.placements.filter {
            config.ads.globalEnabled &&
                    it.enabled &&
                    it.format == "interstitial" &&
                    it.metadata["preload_on_start"].isTruthy()
        }
            .forEach {
                preload(activity, it.name)
            }
    }

    fun preload(activity: Activity, placementName: String) {
        load(activity, placementName, forceRequest = false)
    }

    fun load(activity: Activity, placementName: String, forceRequest: Boolean = false) {
        val config = configProvider()
        if (!config.ads.globalEnabled) return
        if (!NetworkState.isOnline(activity)) return
        val placement = config.ads.placements.firstOrNull {
            it.name == placementName &&
                    it.enabled &&
                    it.format == "interstitial"
        } ?: return

        if (customRenderer.canRender(placement)) {
            customRenderer.preload(activity, placement)
            return
        }

        val unit = placement.units.firstOrNull {
            it.network == "admob"
        } ?: return

        if (loadedAds.containsKey(placementName)) {
            return
        }
        if (!canStartLoad(placementName, placement, forceRequest)) {
            return
        }

        val request = AdRequest.Builder(unit.adUnitId).build()
        AdEventTracker.log("ad_load_requested", placement)
        startPreloader(placementName, unit.adUnitId, request)
    }

    fun show(activity: Activity, placementName: String, onComplete: () -> Unit = {}, ) {
        if (!activity.isUsable()) {
            safeCallback(onComplete)
            return
        }
        val config = configProvider()
        if (!config.ads.globalEnabled) {
            safeCallback(onComplete)
            return
        }
        if (!NetworkState.isOnline(activity)) {
            safeCallback(onComplete)
            return
        }

        val placement = config.ads.placements.firstOrNull {
            it.name == placementName &&
                    it.enabled &&
                    it.format == "interstitial"
        }

        if (placement == null) {
            safeCallback(onComplete)
            return
        }

        if (!frequency.canShow(placement, countTrigger = true)) {
            AdEventTracker.log("ad_frequency_capped", placement)
            safeCallback(onComplete)
            return
        }

        AdEventTracker.log("ad_show_requested", placement)
        if (customRenderer.canRender(placement)) {
            val shown = customRenderer.show(activity, placement, onComplete = {
                AdEventTracker.log("ad_dismissed", placement)
                armInlineSafetyIfNeeded(placement)
                preloadAfterShowIfEnabled(activity, placementName, placement)
                safeCallback(onComplete)
            })
            if (!shown) {
                AdEventTracker.log("ad_suppressed", placement, mapOf("reason" to "fullscreen_ad_active"))
                frequency.refundTrigger(placement)
                safeCallback(onComplete)
            } else {
                AdEventTracker.log("ad_show_started", placement)
                frequency.markShown(placement)
                AdEventTracker.log("ad_impression", placement)
            }
            return
        }

        val ad = loadedAds.remove(placementName) ?: pollPreloadedAd(placementName)

        if (ad == null) {
            load(activity, placementName, forceRequest = true)
            waitForAdAndShow(activity, placementName, onComplete)
            return
        }

        presentAd(activity, placementName, placement, ad, onComplete)
    }

    private fun presentAd(
        activity: Activity,
        placementName: String,
        placement: com.itwingtech.itwingsdk.core.AdPlacementConfig,
        ad: InterstitialAd,
        onComplete: () -> Unit,
    ) {
        val completion = FullscreenCompletion(onComplete)
        val fullscreenOwner = FullscreenAdState.tryBegin("interstitial", placement.name)
        if (fullscreenOwner == null) {
            AdEventTracker.log("ad_suppressed", placement, mapOf("reason" to "fullscreen_ad_active"))
            frequency.refundTrigger(placement)
            completion.complete()
            return
        }
        AdEventTracker.log("ad_show_started", placement)
        ad.adEventCallback = object : InterstitialAdEventCallback {
            override fun onAdShowedFullScreenContent() {
                frequency.markShown(placement)
                AdEventTracker.log("ad_impression", placement)
            }

            override fun onAdDismissedFullScreenContent() {
                loadedAds.remove(placementName)
                AdEventTracker.log("ad_dismissed", placement)
                armInlineSafetyIfNeeded(placement)
                preloadAfterShowIfEnabled(activity, placementName, placement)
                FullscreenAdState.end(fullscreenOwner)
                completion.complete()
            }

            override fun onAdFailedToShowFullScreenContent(
                fullScreenContentError: FullScreenContentError,
            ) {
                loadedAds.remove(placementName)
                AdEventTracker.log("ad_show_failed", placement, mapOf("message" to fullScreenContentError.message))
                frequency.refundTrigger(placement)
                FullscreenAdState.end(fullscreenOwner)
                completion.complete()
            }

            override fun onAdClicked() {
                AdEventTracker.log("ad_click", placement)
            }

            override fun onAdImpression() {
                AdEventTracker.log("ad_impression_recorded", placement)
            }

            override fun onAdPaid(adValue: AdValue) {
                AdEventTracker.log(
                    "ad_paid",
                    placement,
                    mapOf(
                        "revenue_micros" to adValue.valueMicros,
                        "currency" to adValue.currencyCode,
                        "precision" to adValue.precisionType,
                        "ad_unit_id" to (placement.units.firstOrNull { it.network == "admob" }?.adUnitId ?: ""),
                    ),
                )
            }
        }

        runOnMain {
            if (!activity.isUsable()) {
                FullscreenAdState.end(fullscreenOwner)
                completion.complete()
                return@runOnMain
            }
            runCatching {
                ad.show(activity)
            }.onFailure {
                AdEventTracker.log("ad_show_failed", placement, mapOf("message" to (it.message ?: "show_exception")))
                frequency.refundTrigger(placement)
                FullscreenAdState.end(fullscreenOwner)
                completion.complete()
            }
        }
    }

    fun isLoaded(placementName: String, ): Boolean {
        return loadedAds.containsKey(placementName)
    }

    fun clear(placementName: String, ) {
        loadedAds.remove(placementName)
        preloaderKeys[placementName]?.let { InterstitialAdPreloader.destroy(it) }
        preloaderKeys.remove(placementName)
    }

    fun clearAll() {
        loadedAds.clear()
        preloaderKeys.values.forEach { InterstitialAdPreloader.destroy(it) }
        preloaderKeys.clear()
    }

    private fun startPreloader(placementName: String, adUnitId: String, request: AdRequest) {
        if (preloaderKeys[placementName] == adUnitId) {
            return
        }
        preloaderKeys[placementName]?.let { InterstitialAdPreloader.destroy(it) }
        preloaderKeys[placementName] = adUnitId
        runCatching {
            InterstitialAdPreloader.start(
                adUnitId,
                PreloadConfiguration(request, 1),
            )
        }
    }

    private fun preloadAfterShowIfEnabled(
        activity: Activity,
        placementName: String,
        placement: com.itwingtech.itwingsdk.core.AdPlacementConfig,
    ) {
        if (placement.metadata["preload_after_show"].isTruthy()) {
            preload(activity, placementName)
        }
    }

    private fun canStartLoad(
        placementName: String,
        placement: com.itwingtech.itwingsdk.core.AdPlacementConfig,
        forceRequest: Boolean = false,
    ): Boolean {
        if (forceRequest) {
            lastLoadAttemptAt[placementName] = SystemClock.elapsedRealtime()
            return true
        }
        val now = SystemClock.elapsedRealtime()
        val previous = lastLoadAttemptAt[placementName] ?: 0L
        if (now - previous < minLoadIntervalMs) {
            AdEventTracker.log("ad_load_throttled", placement, mapOf("cooldown_ms" to minLoadIntervalMs))
            return false
        }
        lastLoadAttemptAt[placementName] = now
        return true
    }

    private fun pollPreloadedAd(placementName: String): InterstitialAd? {
        val key = preloaderKeys[placementName] ?: return null
        val ad = runCatching { InterstitialAdPreloader.pollAd(key) }.getOrNull()
        if (ad != null) {
            preloaderKeys.remove(placementName)
            runCatching { InterstitialAdPreloader.destroy(key) }
        }
        return ad
    }

    private fun waitForAdAndShow(activity: Activity, placementName: String, onComplete: () -> Unit) {
        val loadingDialog = AdLoadingDialog(activity)
        val app = configProvider().app
        val timeoutMs = (app["loading_ad_timeout_ms"] as? Number)?.toLong() ?: 7000L
        val lottieUrl = app["loading_lottie_url"] as? String
        val startedAt = System.currentTimeMillis()
        loadingDialog.show(lottieUrl)

        fun poll() {
            if (!activity.isUsable()) {
                loadingDialog.dismiss()
                configProvider().ads.placements.firstOrNull {
                    it.name == placementName && it.enabled && it.format == "interstitial"
                }?.let(frequency::refundTrigger)
                safeCallback(onComplete)
                return
            }
            if (!NetworkState.isOnline(activity)) {
                loadingDialog.dismiss()
                configProvider().ads.placements.firstOrNull {
                    it.name == placementName && it.enabled && it.format == "interstitial"
                }?.let(frequency::refundTrigger)
                safeCallback(onComplete)
                return
            }
            val ad = loadedAds.remove(placementName) ?: pollPreloadedAd(placementName)
            if (ad != null) {
                loadingDialog.dismiss()
                val placement = configProvider().ads.placements.firstOrNull {
                    it.name == placementName && it.enabled && it.format == "interstitial"
                }
                if (placement == null) {
                    safeCallback(onComplete)
                } else {
                    presentAd(activity, placementName, placement, ad, onComplete)
                }
                return
            }
            if (System.currentTimeMillis() - startedAt >= timeoutMs) {
                loadingDialog.dismiss()
                clearPreloader(placementName)
                configProvider().ads.placements.firstOrNull {
                    it.name == placementName && it.enabled && it.format == "interstitial"
                }?.let(frequency::refundTrigger)
                safeCallback(onComplete)
                return
            }
            mainHandler.postDelayed({ poll() }, 150L)
        }

        mainHandler.postDelayed({ poll() }, 150L)
    }

    private fun clearPreloader(placementName: String) {
        preloaderKeys.remove(placementName)?.let { key ->
            runCatching { InterstitialAdPreloader.destroy(key) }
        }
    }

    private fun armInlineSafetyIfNeeded(placement: com.itwingtech.itwingsdk.core.AdPlacementConfig) {
        if (placement.isSplashPlacement()) return
        InlineAdSafetyGate.arm("interstitial", placement.name)
    }

    private fun com.itwingtech.itwingsdk.core.AdPlacementConfig.isSplashPlacement(): Boolean {
        val usage = metadata["usage"]?.toString()?.trim().orEmpty()
        val splash = metadata["splash"]
        return name.contains("splash", ignoreCase = true) ||
            usage.equals("splash", ignoreCase = true) ||
            splash == true ||
            splash?.toString()?.equals("true", ignoreCase = true) == true ||
            splash?.toString() == "1"
    }

    private fun Any?.isTruthy(): Boolean {
        return when (this) {
            is Boolean -> this
            is String -> equals("true", ignoreCase = true) || this == "1"
            is Number -> toInt() != 0
            else -> false
        }
    }

    private fun Activity.isUsable(): Boolean = !isFinishing && !isDestroyed

}
